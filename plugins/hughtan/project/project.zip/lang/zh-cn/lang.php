<?php return [
    'plugin' => [
        'name' => '项目',
        'description' => '',
    ],
    'post' => [
        'file' => '文件',
        'title' => '标题',
        'summy' => '摘要',
        'content' => '内容',
        'created_at' => '添加时间',
        'updated_at' => '更新时间',
        'is_public' => '是否公开',
        'icon' => '图标'
    ]
];